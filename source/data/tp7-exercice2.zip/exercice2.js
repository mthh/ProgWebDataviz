document.addEventListener('DOMContentLoaded', async function () {
  // Partie 1
  const map = L.map('map');
  L.tileLayer('https://tiles.stadiamaps.com/tiles/alidade_smooth_dark/{z}/{x}/{y}{r}.png', {
    attribution: "© <a href=https://www.openstreetmap.org/copyright>OpenStreetMap</a> contributors"
  }).addTo(map);

  map.setView([45.1885, 5.7245], 13);

  // Partie 2
  const rPoint = await fetch('https://gist.githubusercontent.com/mthh/0e675c0b582f3cfa5af8171b8c4e9c3d/raw/54969997ebcfa403de3d0b02aadfa09df7ee8038/base_imb_38_grenoble.geojson');
  const dataPoint = await rPoint.json();
  const rPolygon = await fetch('https://gist.githubusercontent.com/mthh/4ad093d3b33c2177f1e6c1ea1cde5d9b/raw/b6a60fc2ee66093f009114331f8a4230665d6a30/UNIONS_DE_QUARTIER_EPSG4326.json');
  const dataPolygon = await rPolygon.json();

  const polygons = L.geoJSON(dataPolygon, {
    style: {
      color: 'red',
      fillOpacity: 0.2
    }
  }).addTo(map);

  const markers = L.markerClusterGroup();

  dataPoint.features.forEach((pt) => {
    const m = L.marker([pt.geometry.coordinates[1], pt.geometry.coordinates[0]]);
    m.bindPopup(`Id: ${pt.properties.imb_id}`);
    m.on('click', () => {
      console.log(pt.properties)
      document.getElementById('info').innerHTML = `
    <h3>Information (id: ${pt.properties.imb_id})</h3>
    <table>
    <thead>
      <tr>
        <th>Numéro</th>
        <th>Nom voie</th>
        <th>Nom commune</th>
        <th>Nombre de logements ou locaux</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>${pt.properties.addr_numero}</td>
        <td>${pt.properties.addr_nom_voie}</td>
        <td>${pt.properties.addr_nom_commune}</td>
        <td>${pt.properties.imb_nbr_logloc}</td>
      </tr>
    </tbody>
  </table>`;
    });
    markers.addLayers(m);
  });

  map.addLayer(markers);

  map.on("click", (e) => {
    document.getElementById('info').innerHTML = ``;
  });
});
