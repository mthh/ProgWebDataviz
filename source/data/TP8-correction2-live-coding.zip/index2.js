document.addEventListener('DOMContentLoaded', async function () {
  const r = await fetch('https://gist.githubusercontent.com/mthh/ff8f4bcacf10a0afe6d1a19556b5cfe7/raw/1f246583a8de3232e6859854ac3315af457626da/BIBLIOTHEQUES_VDG.geojson');
  const data = await r.json();

  // Compute center point
  const centerPoint = [
    d3.sum(data.features, ft => ft.geometry.coordinates[1]) / data.features.length,
    d3.sum(data.features, d => d.geometry.coordinates[0]) / data.features.length,
  ]

  // Create the map and add the tile layer
  const map = L.map('map');

  L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
    subdomains: 'abcd',
    maxZoom: 20
  }).addTo(map);

  map.setView(centerPoint, 13);

  const selectBib = document.getElementById("select-bib");

  data.features.forEach((point) => {
    const marker = L.marker([point.geometry.coordinates[1], point.geometry.coordinates[0]]);
    marker.bindPopup(`${point.properties['CDL-Libelle long Bib']}`);
    marker.on('mouseover', () => marker.openPopup());
    marker.on('mouseout', () => marker.closePopup());
    marker.on('click', () => {
      const selectedBib = point.properties['CDL-Branch Code'];
      selectBib.value = selectedBib;
      createPlot(data, selectedBib);
    });
    marker.addTo(map);
  });

  const bibs = data.features.map(ft => ft.properties['CDL-Libelle long Bib']);
  const ids = data.features.map(ft => ft.properties['CDL-Branch Code']);

  const option = document.createElement("option");
  option.text = 'Toutes les bibliothèques'
  option.value = '';
  selectBib.appendChild(option);

  for (let i = 0; i < bibs.length; i++) {
    const option = document.createElement("option");
    option.text = bibs[i];
    option.value = ids[i];
    selectBib.appendChild(option);
  }

  selectBib.addEventListener('change', event => {
      createPlot(data, event.target.value)
  });
});

function createPlot(data, selectedBib) {
  const years = [2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016]

  const dataInscrits = !selectedBib
    ? years.map(d => ({ year: d, value: d3.sum(data.features, ft => ft.properties[`Inscrits_${d}`])}))
    : years.map(d => ({ year: d, value: data.features.find(ft => ft.properties['CDL-Branch Code'] === selectedBib).properties[`Inscrits_${d}`]}))

  const p = Plot.plot({
    title: 'Nombre d\'inscrits par année',
    marks: [
      Plot.lineY(dataInscrits, { x: 'year', y: 'value', stroke: 'red'})
    ]
  })

  document.querySelector('#graph1').innerHTML = p.outerHTML;

  const dataEmp = !selectedBib
    ? years.map(d => ({ year: d, value: d3.sum(data.features, ft => ft.properties[`Emprunteurs_${d}`])}))
    : years.map(d => ({ year: d, value: data.features.find(ft => ft.properties['CDL-Branch Code'] === selectedBib).properties[`Inscrits_${d}`]}))

  const p1 = Plot.plot({
    title: 'Nombre d\'emprunteurs par année',
    marks: [
      Plot.lineY(dataEmp, { x: 'year', y: 'value', stroke: 'red'})
    ]
  })

  document.querySelector('#graph2').innerHTML = p1.outerHTML;

  const dataVisit = !selectedBib
    ? years.map(d => ({ year: d, value: d3.sum(data.features, ft => ft.properties[`Visiteurss_${d}`])}))
    : years.map(d => ({ year: d, value: data.features.find(ft => ft.properties['CDL-Branch Code'] === selectedBib).properties[`Inscrits_${d}`]}))

  const p2 = Plot.plot({
    title: 'Nombre de visiteurs par année',
    marks: [
      Plot.lineY(dataVisit, { x: 'year', y: 'value', stroke: 'red'})
    ]
  })

  document.querySelector('#graph3').innerHTML = p2.outerHTML;
}