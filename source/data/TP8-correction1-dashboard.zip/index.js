document.addEventListener('DOMContentLoaded', async function () {
  const data = await fetchData();

  const rPolygon = await fetch('https://gist.githubusercontent.com/mthh/4ad093d3b33c2177f1e6c1ea1cde5d9b/raw/b6a60fc2ee66093f009114331f8a4230665d6a30/UNIONS_DE_QUARTIER_EPSG4326.json');
  const dataPolygon = await rPolygon.json();

  let selectedBib = '';

  console.log(data);

  // Compute center point
  const centerPoint = [
    data.features.reduce((sum, point) => sum + point.geometry.coordinates[1], 0) / data.features.length,
    data.features.reduce((sum, point) => sum + point.geometry.coordinates[0], 0) / data.features.length,
  ]

  // Create the map and add the tile layer
  const map = L.map('map');
  L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
    subdomains: 'abcd',
    maxZoom: 20
  }).addTo(map);

  const polygons = L.geoJSON(dataPolygon, {
    style: {
      color: 'red',
      fillOpacity: 0.2
    }
  }).addTo(map);

  // Set the center and zoom level of the map
  map.setView(centerPoint, 13);

  // Add a marker (+ a popup, that appears on mouseover) for each point
  data.features.forEach((point) => {
    const marker = L.marker([point.geometry.coordinates[1], point.geometry.coordinates[0]]);
    marker.bindPopup(`${point.properties['CDL-Libelle long Bib']}`);
    marker.on('mouseover', () => marker.openPopup());
    marker.on('mouseout', () => marker.closePopup());
    marker.on('click', () => {
      selectedBib = point.properties['CDL-Branch Code'];
      document.getElementById('select-bib').value = selectedBib;
      makePlots(data, selectedBib);
    });
    marker.addTo(map);
  });

  // All bib and their id
  const bibs = [...new Set(data.features.map((point) => point.properties['CDL-Libelle long Bib']))];
  const ids = [...new Set(data.features.map((point) => point.properties['CDL-Branch Code']))];

  // Fill the select menu
  const select = document.getElementById('select-bib');

  const firstOption = document.createElement('option');
  firstOption.value = '';
  firstOption.innerHTML = 'Toutes les bibliothèques';
  select.appendChild(firstOption);

  ids.forEach((id, ix) => {
    const option = document.createElement('option');
    option.value = id;
    option.innerHTML = bibs[ix];
    select.appendChild(option);
  });

  select.addEventListener('change', (event) => {
    selectedBib = event.target.value;
    makePlots(data, selectedBib);
  });

  makePlots(data, selectedBib);
});

const makePlots = (data, selectedBib) => {
  console.log(selectedBib);
  // Clean the existing plots if any
  document.getElementById('graph1').innerHTML = '';
  document.getElementById('graph2').innerHTML = '';
  document.getElementById('graph3').innerHTML = '';
  document.getElementById('graph4').innerHTML = '';

  if (!selectedBib) {
    // Prepare the data for the plots, for all the bibs
    const keys = Object.keys(data.features[0].properties);
    const inscrits = keys.filter((key) => key.includes('Inscrits')).map((key) => ({ year: +key.split('_')[1], value: data.features.reduce((sum, point) => sum + point.properties[key], 0) }));
    const prets = keys.filter((key) => key.includes('Prets')).map((key) => ({ year: +key.split('_')[1], value: data.features.reduce((sum, point) => sum + point.properties[key], 0) }));
    const emprunteurs = keys.filter((key) => key.includes('Emprunteurs')).map((key) => ({ year: +key.split('_')[1], value: data.features.reduce((sum, point) => sum + point.properties[key], 0) }));
    const visiteurs = keys.filter((key) => key.includes('Visiteurs')).map((key) => ({ year: +key.split('_')[1], value: data.features.reduce((sum, point) => sum + point.properties[key], 0) }));

    const plot1 = Plot.plot({
      title: 'Évolution du nombre d\'inscrits',
      marks: [
        Plot.lineY(inscrits, {x: "year", y: "value", stroke: 'blue'}),
        Plot.frame(),
      ],
    });
    document.getElementById('graph1').innerHTML = `${plot1.outerHTML}`;

    const plot2 = Plot.plot({
      title: 'Évolution du nombre de prêts',
      marks: [
        Plot.lineY(prets, {x: "year", y: "value", stroke: 'red'}),
        Plot.frame(),
      ],
    });
    document.getElementById('graph2').innerHTML = `${plot2.outerHTML}`;

    const plot3 = Plot.plot({
      title: 'Évolution du nombre d\'emprunteurs',
      marks: [
        Plot.lineY(emprunteurs, {x: "year", y: "value", stroke: 'green'}),
        Plot.frame(),
      ],
    });
    document.getElementById('graph3').innerHTML = `${plot3.outerHTML}`;

    const plot4 = Plot.plot({
      title: 'Évolution du nombre de visiteurs',
      marks: [
        Plot.lineY(visiteurs, {x: "year", y: "value", stroke: 'orange'}),
        Plot.frame(),
      ],
    });
    document.getElementById('graph4').innerHTML = `${plot4.outerHTML}`;
    return;
  }
  const keys = Object.keys(data.features[0].properties);
  const selectedBibData = data.features.find((point) => point.properties['CDL-Branch Code'] === selectedBib);
  const inscrits = keys.filter((key) => key.includes('Inscrits')).map((key) => ({ year: +key.split('_')[1], value: selectedBibData.properties[key] }));
  const prets = keys.filter((key) => key.includes('Prets')).map((key) => ({ year: +key.split('_')[1], value: selectedBibData.properties[key] }));
  const emprunteurs = keys.filter((key) => key.includes('Emprunteurs')).map((key) => ({ year: +key.split('_')[1], value: selectedBibData.properties[key] }));
  const visiteurs = keys.filter((key) => key.includes('Visiteurs')).map((key) => ({ year: +key.split('_')[1], value: selectedBibData.properties[key] }));

  if (!inscrits.every((d) => d.value === 0 || d.value === null)) {
    const plot1 = Plot.plot({
      title: 'Évolution du nombre d\'inscrits',
      marks: [
        Plot.lineY(inscrits, {x: "year", y: "value", stroke: 'blue'}),
        Plot.frame(),
      ],
    });
    document.getElementById('graph1').innerHTML = `${plot1.outerHTML}`;
  } else {
    document.getElementById('graph1').innerHTML = '<i>Pas de données "Inscrits" pour cette bibliothèque</i>';
  }

  if (!prets.every((d) => d.value === 0 || d.value === null)) {
    const plot2 = Plot.plot({
      title: 'Évolution du nombre de prêts',
      marks: [
        Plot.lineY(prets, {x: "year", y: "value", stroke: 'red'}),
        Plot.frame(),
      ],
    });
    document.getElementById('graph2').innerHTML = `${plot2.outerHTML}`;
  } else {
    document.getElementById('graph2').innerHTML = '<i>Pas de données "Prêts" pour cette bibliothèque</i>';
  }

  if (!emprunteurs.every((d) => d.value === 0 || d.value === null)) {
    const plot3 = Plot.plot({
      title: 'Évolution du nombre d\'emprunteurs',
      marks: [
        Plot.lineY(emprunteurs, {x: "year", y: "value", stroke: 'green'}),
        Plot.frame(),
      ],
    });
    document.getElementById('graph3').innerHTML = `${plot3.outerHTML}`;
  } else {
    document.getElementById('graph3').innerHTML = '<i>Pas de données "Emprunteurs" pour cette bibliothèque</i>';
  }

  if (!visiteurs.every((d) => d.value === 0 || d.value === null)) {
    const plot4 = Plot.plot({
      title: 'Évolution du nombre de visiteurs',
      marks: [
        Plot.lineY(visiteurs, {x: "year", y: "value", stroke: 'orange'}),
        Plot.frame(),
      ],
    });
    document.getElementById('graph4').innerHTML = `${plot4.outerHTML}`;
  } else {
    document.getElementById('graph4').innerHTML = '<i>Pas de données "Visiteurs" pour cette bibliothèque</i>';
  }
  return;
};

async function fetchData() {
  const r = await fetch('https://gist.githubusercontent.com/mthh/ff8f4bcacf10a0afe6d1a19556b5cfe7/raw/1f246583a8de3232e6859854ac3315af457626da/BIBLIOTHEQUES_VDG.geojson');
  return r.json();
}
