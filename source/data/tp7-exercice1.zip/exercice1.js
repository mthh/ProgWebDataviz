const points = [
  {"latitude":48.00437060928802,"longitude":3.405187984560979,"value":92.23933026058458},
  {"latitude":44.463307782881934,"longitude":2.5867921967706105,"value":78.59774966580932},
  {"latitude":46.701360118007614,"longitude":-4.203438300412598,"value":43.30792363015428},
  {"latitude":48.06995454268257,"longitude":2.9843755928045974,"value":69.75382042731478},
  {"latitude":41.73849513342013,"longitude":0.09524315874835665,"value":42.34848301924781},
  {"latitude":47.5131048425846,"longitude":1.3759605086441091,"value":65.13901308010112},
  {"latitude":48.27480094773302,"longitude":1.5415705159709354,"value":76.69398811189502},
  {"latitude":49.04183370083771,"longitude":2.0131437190407855,"value":99.75806820665699},
  {"latitude":45.73365334672548,"longitude":4.509047183911503,"value":49.39182573091858},
  {"latitude":41.56944827203337,"longitude":1.2824369841638328,"value":98.8118003058305},
  {"latitude":50.28025539589674,"longitude":-2.5204876565287906,"value":33.777649042471914},
  {"latitude":50.04283122112549,"longitude":-1.7658824325843097,"value":22.348104425941106},
  {"latitude":50.63019093091029,"longitude":5.955827423893109,"value":50.041803065894655},
  {"latitude":50.809542049709066,"longitude":-1.0519506280225759,"value":13.303012538593073},
  {"latitude":44.759611774817465,"longitude":8.241677659885802,"value":52.730646258111236},
  {"latitude":42.14041661862867,"longitude":-0.8466411995457843,"value":61.63346482605998},
  {"latitude":45.556856299199055,"longitude":1.7522494113772655,"value":16.73165840302704},
  {"latitude":47.63444578836868,"longitude":-0.40224418700704234,"value":6.902395475369105},
  {"latitude":43.604840774530444,"longitude":5.95782358092385,"value":75.69673343311065},
  {"latitude":46.002160655169575,"longitude":9.359492147779932,"value":94.2702706591928},
  {"latitude":41.869003589884436,"longitude":-1.2802888695794739,"value":95.2801673714837},
  {"latitude":45.1080605850212,"longitude":-0.45234191130153434,"value":51.73082356043059},
  {"latitude":48.54857370885016,"longitude":1.7114593757958412,"value":87.32096049949669},
  {"latitude":44.57759194158374,"longitude":-0.7839355503934682,"value":99.80646228576471},
  {"latitude":42.48443600589425,"longitude":6.019292339960644,"value":78.37483977153656},
  {"latitude":42.60198736310705,"longitude":8.116480723726443,"value":66.25562229170268},
  {"latitude":49.73466522334483,"longitude":6.84746537289261,"value":96.27957332154588},
  {"latitude":47.83480704252232,"longitude":-2.745650502291979,"value":50.169730353307784},
  {"latitude":46.21512871086712,"longitude":-2.300736925259019,"value":53.2481339356941},
  {"latitude":45.02797280582468,"longitude":7.018468421305442,"value":11.149581436133339},
  {"latitude":50.54459158166243,"longitude":4.777331391551614,"value":36.37465244653624},
  {"latitude":47.96646869174493,"longitude":-3.6750860883761627,"value":82.54139905132811},
  {"latitude":48.19889401847914,"longitude":-2.748243099974136,"value":44.54208502616732},
  {"latitude":49.18305491665355,"longitude":8.58129751703601,"value":52.811224974824135},
  {"latitude":42.428388231599435,"longitude":2.2081712468493713,"value":39.87227700369287},
  {"latitude":48.767901025926975,"longitude":3.3675651108011673,"value":92.36195957310247},
  {"latitude":49.46087504501311,"longitude":4.444836603405148,"value":98.91746712178988},
  {"latitude":43.95537474837441,"longitude":8.25719417920605,"value":86.41568950094754},
  {"latitude":46.07404357424273,"longitude":-4.5995135972665055,"value":32.26512855436787},
  {"latitude":48.679162231135216,"longitude":3.6007153060206045,"value":93.34158555286103},
  {"latitude":47.266094787298535,"longitude":8.055574091658201,"value":41.1033164478011},
  {"latitude":45.49807875479245,"longitude":7.518082870711052,"value":72.49838154223822},
  {"latitude":47.969680565487835,"longitude":-0.8713047702640733,"value":33.98535164114689},
  {"latitude":47.431616715860365,"longitude":-4.613929658904625,"value":50.64590085936243},
  {"latitude":41.514760853194815,"longitude":2.285139281037278,"value":89.68834138037607},
  {"latitude":46.56277459901562,"longitude":-1.3184048033881233,"value":33.400280682161146},
  {"latitude":46.5316977344798,"longitude":6.603077148212063,"value":72.0113752609356},
  {"latitude":48.29954528284932,"longitude":-2.3863072660138696,"value":64.53094764875222},
  {"latitude":50.91688820075097,"longitude":-1.8342393474682077,"value":72.95221657545406},
  {"latitude":41.63495049806509,"longitude":1.6269678922727104,"value":60.558472875675264},
  {"latitude":48.71181524949577,"longitude":5.0903550879247055,"value":19.438782471998707},
  {"latitude":49.87744549421906,"longitude":5.230083842017458,"value":47.323728454689395},
  {"latitude":43.79607186816448,"longitude":9.03513208547697,"value":7.984347750004095},
  {"latitude":50.60528678874444,"longitude":0.24209221800012326,"value":85.64259358587825},
  {"latitude":50.01321909828898,"longitude":-0.23700944427613369,"value":92.35686482899119},
  {"latitude":48.36372866930204,"longitude":6.778863311345785,"value":73.70427600933832},
  {"latitude":41.63022408790834,"longitude":8.389941106538636,"value":51.005368006226504},
  {"latitude":41.57650161768758,"longitude":9.433710257487771,"value":72.50846938530762},
  {"latitude":46.63836538999862,"longitude":6.283146871291595,"value":89.57409452155638},
  {"latitude":50.644305399960444,"longitude":1.3723843448788715,"value":30.123756037195815},
  {"latitude":50.49617922119971,"longitude":1.4829072337520204,"value":41.95864161331395},
  {"latitude":44.06713285045802,"longitude":-2.0750725846461107,"value":39.03465413141449},
  {"latitude":42.004837157200875,"longitude":2.4709605423322545,"value":1.6057082848583093},
  {"latitude":44.843053335216204,"longitude":6.155960869148214,"value":83.26243524621071},
  {"latitude":50.59541470550611,"longitude":6.813655963218163,"value":55.47643509191145},
  {"latitude":48.109448920624054,"longitude":-2.937552742927649,"value":6.694287348602335},
  {"latitude":46.46951788080611,"longitude":3.769992632761906,"value":95.11842643973142},
  {"latitude":42.85539608851279,"longitude":7.663502275531511,"value":72.81715035933401},
  {"latitude":46.64295606637092,"longitude":3.026217599936328,"value":90.53437573839017},
  {"latitude":49.104242123946804,"longitude":1.4644361383473088,"value":78.38285495339304},
  {"latitude":45.966573558689234,"longitude":6.244733093756412,"value":45.010766988063125},
  {"latitude":48.04756186923966,"longitude":0.49753046080660557,"value":40.809650976483795},
  {"latitude":47.1720371306031,"longitude":-3.6394494864748514,"value":67.05264046083512},
  {"latitude":47.84275126525832,"longitude":-2.3233366820057477,"value":36.036798691745545},
  {"latitude":47.430993231382885,"longitude":-4.007409918464976,"value":63.13549493741286},
  {"latitude":42.297505161919844,"longitude":1.0880004632343923,"value":97.46177848824912},
  {"latitude":51.03289119651886,"longitude":4.4007045353275815,"value":85.18369801298708},
  {"latitude":43.178360461068245,"longitude":-0.009674080605641677,"value":42.944371900740364},
  {"latitude":49.20587571878736,"longitude":5.55464419664852,"value":17.77257142847848},
  {"latitude":42.122136495152866,"longitude":-1.2355788150693159,"value":78.44912528713368},
  {"latitude":44.337872682975195,"longitude":3.7900019533661,"value":62.72653881661314},
  {"latitude":49.28765986966627,"longitude":-4.984572140202957,"value":55.454115542254634},
  {"latitude":49.87062696418933,"longitude":7.415757701119513,"value":56.0506289149177},
  {"latitude":41.99264374695782,"longitude":7.391627348898672,"value":33.81696479960035},
  {"latitude":50.52538329252816,"longitude":8.380066077678489,"value":5.265642257243974},
  {"latitude":48.33537921772958,"longitude":-2.658881052479613,"value":33.13221190392888},
  {"latitude":45.23568718489072,"longitude":8.446979452411746,"value":88.76351607709296},
  {"latitude":43.14395880940174,"longitude":-2.781095276519064,"value":15.820755735291424},
  {"latitude":49.635433559883246,"longitude":3.9729266229413254,"value":39.24223351995748},
  {"latitude":42.604919737160785,"longitude":-0.352301384476597,"value":31.99633524706693},
  {"latitude":47.23421475240264,"longitude":4.288401250312162,"value":25.435119853526377},
  {"latitude":49.32378149019271,"longitude":9.204959065600708,"value":48.53810466010362},
  {"latitude":44.79617633536024,"longitude":0.5052328945724387,"value":78.0750273964333},
  {"latitude":47.62248657471929,"longitude":8.964901395861006,"value":9.099582137317718},
  {"latitude":44.98601257661349,"longitude":-3.011559799044299,"value":8.417443213093279},
  {"latitude":46.78555138978771,"longitude":-0.9580818337470696,"value":43.29107594150834},
  {"latitude":48.06471866986791,"longitude":-2.648041608657923,"value":69.0894624195032},
  {"latitude":50.16178092012635,"longitude":2.7209265750118803,"value":4.145746145562623},
  {"latitude":49.3415677365672,"longitude":9.38684509906168,"value":40.08902664621343},
  {"latitude":45.93740084771017,"longitude":-2.2680835197324423,"value":85.57974779137525}
];

const greenIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const orangeIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-orange.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const redIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
})

const centerPoint = [
  points.reduce((sum, point) => sum + point.latitude, 0) / points.length,
  points.reduce((sum, point) => sum + point.longitude, 0) / points.length
]

document.addEventListener('DOMContentLoaded', async function () {
  // Partie 1
  const map = L.map('map');
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "© <a href=https://www.openstreetmap.org/copyright>OpenStreetMap</a> contributors"
  }).addTo(map);

  map.setView(centerPoint, 6);

  // Partie 2 - Ajout d'un marqueur pour chaque point et d'un popup lors du clic
  points.forEach(point => {
    const icon = point.value < 33 ? greenIcon : point.value < 66 ? orangeIcon : redIcon;
    const marker = L.marker([point.latitude, point.longitude], { icon }).addTo(map);
    marker.bindPopup(`<b>Valeur</b> : ${point.value}`);
  })
});